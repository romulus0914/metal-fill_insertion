# iccad2018-contest
problem C: Timing aware metal fill

Test case 1: circuit1.tar.gz (revised: all via polygons removed)

Test case 2: circuit2.tar.gz (revised: all via polygons removed)

Test case 3: circuit3.tar.gz 

Test case 4: circuit4.tar.gz 

Test case 5: circuit5.tar.gz 


-------------------revise May 3, 2018------------------------

Fixed format problem in process.dat. You can redownload all the cases or only downlaod process.dat, and use it to overwrite old process.dat  in each case.


